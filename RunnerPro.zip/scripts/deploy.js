// scripts/deploy.js
const hre = require("hardhat");
async function main() {
  const Runner = await hre.ethers.getContractFactory("RunnerToken");
  const runner = await Runner.deploy();
  await runner.deployed();
  console.log("RunnerToken (DRUN) deployed to:", runner.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
