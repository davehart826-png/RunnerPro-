require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

const ALCHEMY = process.env.ALCHEMY_API_URL;
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const CONTRACT_ADDRESS = process.env.CONTRACT_ADDRESS;
const PORT = process.env.PORT || 5000;

if(!ALCHEMY || !PRIVATE_KEY) {
  console.warn('Warning: Missing .env values. Please copy .env.example and fill values.');
}

const provider = new ethers.JsonRpcProvider(ALCHEMY);
const wallet = new ethers.Wallet(PRIVATE_KEY, provider);

// Try to load ABI artifact if present
let abi = null;
const artifactPath = path.join(__dirname, '..', 'artifacts', 'contracts', 'RunnerToken.sol', 'RunnerToken.json');
if (fs.existsSync(artifactPath)) {
  const art = JSON.parse(fs.readFileSync(artifactPath));
  abi = art.abi;
} else {
  abi = [
    "function rewardPlayer(address player) external",
    "function balanceOf(address) view returns (uint256)"
  ];
}

const contract = new ethers.Contract(CONTRACT_ADDRESS, abi, wallet);

app.get('/', (req, res) => res.send({ status: 'RunnerPro backend ok' }));

app.get('/api/contract', (req, res) => {
  res.send({ contract: CONTRACT_ADDRESS });
});

// POST endpoint: /api/reward?address=0x...
app.post('/api/reward', async (req, res) => {
  try {
    const player = req.query.address || (req.body && req.body.address);
    if(!player) return res.status(400).send({ error: 'Missing address' });
    const tx = await contract.rewardPlayer(player);
    const receipt = await tx.wait();
    return res.send({ success: true, tx: tx.hash });
  } catch (err) {
    console.error('Reward error', err);
    return res.status(500).send({ error: err.message || String(err) });
  }
});

app.listen(PORT, () => {
  console.log(`RunnerPro backend listening on ${PORT}`);
  console.log(`Contract address: ${CONTRACT_ADDRESS}`);
});
