# RunnerPro — Full Project

Built by Dave_web3

RunnerPro is a beginner-friendly Play-to-Earn demo using a simple runner minigame.
Players earn 0.5 $DRUN tokens when they win.

## What's included
- contracts/RunnerToken.sol (DRUN token)
- scripts/deploy.js (Hardhat deploy script)
- frontend/index.html (demo UI)
- backend/ (Express server that mints rewards)
- hardhat.config.js, package.json, .env.example

## Quick start (local)
1. Install Node.js (16+)
2. Unzip and open the project folder:
   ```
   cd RunnerPro
   npm install
   ```
3. Compile and deploy the contract:
   - Create `.env` from `.env.example` and set `ALCHEMY_API_URL` and `DEPLOYER_PRIVATE_KEY`.
   - `npx hardhat compile`
   - `npx hardhat run scripts/deploy.js --network sepolia`
   - Copy the deployed contract address.
4. Configure backend:
   - `cd backend`
   - copy `.env.example` to `.env` and set `ALCHEMY_API_URL`, `PRIVATE_KEY` and `CONTRACT_ADDRESS`
   - `npm install`
   - `node index.js`
5. Open `frontend/index.html` in your browser, connect MetaMask (Sepolia), and play.

## Deploy backend to Render
1. Push the `backend` folder to GitHub (create repo `runnerpro-backend`)
2. On Render, create a new Web Service and connect the repo.
   - Build Command: `npm install`
   - Start Command: `node index.js`
3. Add environment variables in Render from `backend/.env.example`.
4. Deploy and note the Render URL. Update `frontend/index.html` BACKEND_URL to the Render URL.

## Notes & security
- This demo mints with the backend's private key. Use a dedicated test wallet and never commit real keys to GitHub.
- Add rate-limiting and authentication for production.

Built by Dave_web3
